package com.sample;

public class Add {
	public static void main(String arg[]) {
//		System.out.println("sakthi");
		int a,b,sum;
		a=20;b=10;
		sum=a+b;
		System.out.println("the sum"+sum);
		
		System.out.println(a+b);
		
		System.out.println("the sum"+a+b);
		
		System.out.println("the sum"+(a+b));

	}
}
