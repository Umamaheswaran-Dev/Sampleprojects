package com.sample;

import java.util.Scanner;

public class OddOrEven {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the value");
		int N = scan.nextInt();
		if(N%2!=0){
			System.out.println("The number is Odd");
		}
		else if (N%2==0&&N<20){
			System.out.println("Even and the given number is less than 20...");
		}
		else{
			System.out.println("even and given no is greater than 20");
		}
	}

}
