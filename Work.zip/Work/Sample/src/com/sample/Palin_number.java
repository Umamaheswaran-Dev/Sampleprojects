package com.sample;

import java.util.Scanner;

public class Palin_number {

	public static void main(String[] args) {
		Scanner X = new Scanner(System.in);
		float r;
		float sum = 0;
		float temp;
		System.out.println("the num:");
		float n = X.nextInt();
		temp = n;
		while (n > 0) {
			r = n % 10;
			sum = (sum * 10) + r;
			n = n / 10;
		}
		if (temp == sum) {
			System.out.println("Th given number is palindrome :");
		} else {
			System.out.println("It is not panlindrome");
		}

	}

}
