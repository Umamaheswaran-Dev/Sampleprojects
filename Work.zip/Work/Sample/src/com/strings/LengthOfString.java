package com.strings;

public class LengthOfString {

	
	public static void main(String[] args) {
		String S ="The amazing spider-man";
		 System.out.println("the size of string is :"+S.length());
		 int index1=S.indexOf("amazing");
		 System.out.println("the index of word " + index1);

	}
    
}
