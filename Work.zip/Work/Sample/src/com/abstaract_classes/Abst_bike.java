package com.sample;

class Abst_bike {
	void run() {
		System.out.println("8Test");
	}
}

class Honda extends Abst_bike {
	void run() {
		System.out.println("RUNNING");
	}

	public static void main(String[] args) {
		Abst_bike AB = new Honda();
		AB.run();
	}
}
