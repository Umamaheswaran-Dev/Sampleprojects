package com.sample;

interface Food {
	void briyani();
}

interface Food_2 {
	int shawarma();
}

public class Interface_food implements Food, Food_2 {

	public void briyani() {
		System.out.print("BRIYANI:");
		System.out.println("LOVELY");
	}

	public int shawarma() {
		System.out.print("SHAWARMA:");
		System.out.println("NOT NICE");
		return 2;
	}

	public static void main(String[] args) {
		int result;
		Interface_food r = new Interface_food();
		r.briyani();
		System.out.println(r.shawarma());
		result = r.shawarma();
		System.out.println("result: "+result);
	}

}
