package com.selection_loops;

public class Nested_if_loop {

	public static void main(String[] args) {
		int a = 5;

		if (a < 5) {
			System.out.println(" M A S S ");
		}

		else if (a == 5) {
			System.out.println(" C L A S S ");

		} else {
			System.out.println(" I N V A I L D ");
		}

	}
}
