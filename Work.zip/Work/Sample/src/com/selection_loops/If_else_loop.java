package com.selection_loops;

public class If_else_loop {

	public static void main(String[] args) {
		int a = 5;

		if (a < 5) {
			System.out.println(" M A S S ");
		}

		else {
			System.out.println(" C L A S S ");
		}
	}

}
