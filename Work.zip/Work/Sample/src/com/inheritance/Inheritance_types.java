package com.sample;

public class Inheritance_types {
	void Ajith ()
	{
		System.out.print("Ajith the mass:");
		System.out.println("money money money");
	}
}
class Type_1 extends  Inheritance_types
{
	void vijay ()
	{
		System.out.print("vijay the class:");
		System.out.println("vathi coming");
	}
}
	class Type_2 extends Inheritance_types
	{
		void Surya()
		{
			
		System.out.print("surya the damasu:");
		System.out.println("damasu");
		}
	
	
public static void main(String[] args)
{
	Type_2 T = new Type_2();
	T.Ajith();
	T.Surya();
	Type_1 T1=new Type_1();
	T1.Ajith();
	T1.vijay();
	

}
	}
	

