import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToolsQA {
            public static void main (String []args ) {
        	
         System.setProperty("webdriver.chrome.driver","F:\\Selenium\\chromedriver.exe");
         
        	WebDriver driver = new ChromeDriver();
        	
          	driver.manage().window().fullscreen();
          	
           	driver.get("https://demoqa.com/automation-practice-form");
           	
           	boolean title = driver.findElement(By.xpath("//div[@class='main-header']")).isDisplayed();
            System.out.println("Title displyed"+ title);
             
            
           
           
        }
}
