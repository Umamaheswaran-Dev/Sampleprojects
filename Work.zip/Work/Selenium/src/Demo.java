import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Demo {

	
	public static void main(String[] args) {
		
	System.setProperty("webdriver.chrome.driver","F:\\Selenium\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.manage().window().maximize();
	
	driver.get("http://demo.automationtesting.in/Register.html");-
	
	//driver.findElement(By.xpath("//h2[text()='Register']")).isDisplayed();
	boolean title =driver.findElement(By.xpath("//h2[text()='Register']")).isDisplayed();
	System.out.println(" Title is displayed :" + title  );
	
	//driver.findElement(By.xpath("//input[@placeholder='Search Google or type a URL']")).sendKeys("sakthi");
	driver.findElement(By.xpath("//input[@ng-model='FirstName']")).sendKeys("Sakthimanikandan");
	
	driver.findElement(By.xpath("//input[@ng-model='LastName']")).sendKeys("K");
	
	driver.findElement(By.xpath("//textarea[@ng-model='Adress']")).sendKeys("Chennai");
	
	driver.findElement(By.xpath("//input[@ng-model='EmailAdress']")).sendKeys("sakthifeb98@gmail.com");

	driver.findElement(By.xpath("//input[@ng-model='Phone']")).sendKeys("8838340609");
	
	driver.findElement(By.xpath("//input[@value='Male']")).click();
	
	driver.findElement(By.xpath("//input[@value='Cricket']")).click();
	
	Select dropskills =new Select (driver.findElement(By.xpath("//select[@id='Skills']")));
	
	dropskills.selectByVisibleText("SQL");
	
	Select dropcountry =new Select (driver.findElement(By.xpath("//select[@id='country']")));
	
	dropcountry.selectByValue("India");
	
	Select dropyear =new Select (driver.findElement(By.xpath("//select[@id='yearbox']")));
	
	dropyear.selectByValue("1998");
	
	Select dropmonth =new Select (driver.findElement(By.xpath("//select[@ng-model='monthbox']")));
	
	dropmonth.selectByVisibleText("February");
	
	Select dropday =new Select (driver.findElement(By.xpath("//select[@ng-model='daybox']")));
	
	dropday.selectByVisibleText("7");
	
	driver.findElement(By.xpath("//input[@ng-model='Password']")).sendKeys("P@ssw0rd");
	
	driver.findElement(By.xpath("//input[@ng-model='CPassword']")).sendKeys("P@ssw0rd");
	
	//String text =driver.findElement(By.xpath("")).getText();
	 
	driver.findElement(By.xpath("//button[@id='submitbtn']")).click();
	
	
	
	}

}
