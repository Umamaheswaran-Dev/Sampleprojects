import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;                                                                                                                                                                                                         

public class Particesite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.setProperty("webdriver.chrome.driver","F:\\Selenium\\chromedriver.exe");
     
    
       
   	WebDriver driver = new ChromeDriver();
	
   	driver.manage().window().maximize();
   	 
   	driver.get("http://practice.automationtesting.in/");
   	
   	Tabs ts =new Tabs ();
   	
   //	ts.clickmenu();
   	
   	
	}

}
