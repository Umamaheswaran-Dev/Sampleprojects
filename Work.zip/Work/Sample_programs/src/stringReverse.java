
public class stringReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// String string = "Dream big";
		// Stores the reverse of given string
		// String reversedStr = "";

		// Iterate through the string from last and add each character to variable
		// reversedStr
		// for(int i = string.length()-1; i >= 0; i--){
		// reversedStr = reversedStr + string.charAt(i);
		// }

		// System.out.println("Original string: " + string);
		// System.out.println("Reverse of given string: " + reversedStr);
		// }
		{
			String str = "SAKTHI";
			String reverseStr = "";
			for (int j = str.length() - 1; j >= 0; j--) {
				reverseStr = reverseStr + str.charAt(j);
			}
			System.out.println(" Given string = " + str);
			System.out.println("Reversed String  = " + reverseStr);
		}

	}
}
