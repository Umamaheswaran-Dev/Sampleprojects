package Assignment4Dec10;

public class TransactionLimit extends Exception {
 public TransactionLimit (String message) {
	 super (message);
 }
}
