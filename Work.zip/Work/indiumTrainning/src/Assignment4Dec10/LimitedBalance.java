package Assignment4Dec10;

public class LimitedBalance extends Exception {
     public LimitedBalance (String message) {
    	 super (message);
     }
}
