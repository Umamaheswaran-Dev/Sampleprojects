package Assignment4Dec10;

public class ExceedsLimitations extends Exception {
	public ExceedsLimitations (String message) {
		super(message);
	}

}
