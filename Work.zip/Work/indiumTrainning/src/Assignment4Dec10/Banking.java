package Assignment4Dec10;

import java.util.Scanner;

public class Banking {
	Scanner sc = new Scanner(System.in);

	// int i = sc.nextInt();
	double AccountBalance = 2000;

	public void withdraw() {

		try {
			while (true) {
				System.out.println("Enter Withdrawal Amount :");

				double WithdrawalAmount = sc.nextDouble();

			/*	if (WithdrawalAmount > AccountBalance) {
					throw new MinimumException("Insuffient Amount");
				}*/
				if ( AccountBalance - WithdrawalAmount < 1000) {
					throw new LimitedBalance("minimum balance RS :1000 ,withdraw upto 1000");
				}
				
				  while(WithdrawalAmount - AccountBalance > 100000) { throw new
				  TransactionLimit("Transaction Limit Reached"); }
				 
				int count = 0;
				if (count >= 3) {

					// System.out.println("Enter withdrawAmount :");
					throw new ExceedsLimitations("Exceeds 3 withdraw limitations");
				}
				System.out.println("Succesfully Withdrawn");
				AccountBalance = AccountBalance - WithdrawalAmount;
				count++;
				System.out.println("Available balance : " + AccountBalance);
				System.out.println("Do you want to continue? Y/N");
				String c = sc.next();
				if (c.equals("N")) {
					break;
				}
			}
		}
	/* catch (MinimumException e) {
			System.out.println(e.getMessage());
			System.out.println("Cheack Available Balance");
		} */
		catch (LimitedBalance e) {
			System.out.println(e.getMessage());
		}
		
		  catch (TransactionLimit e) { System.out.println(e.getMessage()); }
		 
		catch (ExceedsLimitations e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Thankyou");
	}

	public static void main(String[] args) {
		Banking b = new Banking();
		b.withdraw();

	}

}
