package Assignment4Dec10;

public class MinimumException extends Exception {

public MinimumException (String message ) {
	super (message);
}

}
