package Basics;

public class collegedetails {

	public static void main(String[] args) {
		College clg = new College("xxx", 123, "yyy");
		clg.clgDetails();

	}

	
}