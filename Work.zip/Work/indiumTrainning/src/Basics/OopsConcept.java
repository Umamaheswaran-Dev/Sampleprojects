package Basics;

import java.util.Scanner;

public class OopsConcept {

	public static void main(String[] args) {
		 System.out.println("Enter values :");
		 
		Scanner sc = new Scanner ( System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		
	
		ArithmaticOperationInterface aot = new ArithmaticOperations (); 
		
		int sum = aot.add(a,b);
		int sum1 = aot.add(a, b, c);
		int sub = aot.subtract(a, b);
		int multiply =aot.multiply(a,b);
		int division =aot.division(a,b);
		
		System.out.println("sum of three num"+sum1);
        System.out.println("sum"+sum);
        System.out.println("difference"+sub);
        System.out.println("Product"+multiply);
        System.out.println("Balance"+division);
	}

}
