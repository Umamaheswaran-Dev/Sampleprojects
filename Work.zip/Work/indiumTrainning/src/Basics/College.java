package Basics;

public class College {
 String college_name;
 int stud_id ;
 String stud_dept;
  
 public College( String college_name ,int stud_id ,String stud_dept) {
	 this. college_name=college_name;
	 this.stud_id=stud_id;
	 this. stud_dept=stud_dept;
 }
 
 public void clgDetails() 
 {
	 
	 System.out.println ("college_name"+college_name);
     System.out.println("stud_id"+ stud_id);
     System.out.println("stud_dept"+stud_dept);
     
    // return "Colleg name" + this.college_name;
 }
 
	 
 }

