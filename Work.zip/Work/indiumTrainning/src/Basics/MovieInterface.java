package Basics;

public interface MovieInterface {
	void checkMovieAvailablity();
	void checkAvailableTickets();
	void displayTicketPrice();
	void showTotalAmount();

	

}
