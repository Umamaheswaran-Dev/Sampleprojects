package Basics;

public interface ArithmaticOperationInterface {
	
       int add (int a, int b);
       int add (int a, int b, int c);
       
       int subtract (int a, int b);
       
       
       int multiply ( int a , int b);
       
       int division (int a, int b);

}
