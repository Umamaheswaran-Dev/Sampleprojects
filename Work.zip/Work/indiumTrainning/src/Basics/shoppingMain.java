
package Basics;

import java.util.Scanner;

public class shoppingMain {

	public static void main(String[] args) 
	{
   	Scanner sc = new Scanner(System.in);
   	shopping shop =new shopping();
   	
//	 String Dress =sc.next();
	 shop.setDress(sc.next());
	  
	 int dress_price =sc.nextInt();
	 shop.setDress_price(dress_price);
	 
	 String payment_by = sc.next();
	 shop.setPaymnet_by(payment_by);
	 
	 System.out.println("Dress :" +shop.getDress() );
	 System.out.println("dress_price" + shop.getDress_price());
	 System.out.println("payment_by" +shop.getPaymnet_by());

	}

}