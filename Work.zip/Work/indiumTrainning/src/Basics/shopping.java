package Basics;

public class shopping {
	private String dress;
	private int dress_price ;
	private String paymnet_by;
	
	public String getDress() {
		return dress;
	}
	public void setDress(String dress) {
		this.dress = dress;
	}
	public int getDress_price() {
		return dress_price;
	}
	public void setDress_price(int dress_price) {
		this.dress_price = dress_price;
	}
	public String getPaymnet_by() {
		return paymnet_by;
	}
	public void setPaymnet_by(String paymnet_by) {
		this.paymnet_by = paymnet_by;
	}

}
