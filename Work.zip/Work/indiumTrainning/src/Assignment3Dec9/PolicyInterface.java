package Assignment3Dec9;

public interface PolicyInterface {
           void PensionPlans();
           void healthPlans();
           void individualPlans();
           void GroupSchemes();
           
}
