package Assignment3Dec9;



public class demo {
	
 
 public static void main(String[] args) throws Exception {
 A a=new A
 }
}
