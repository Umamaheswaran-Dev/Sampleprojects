package Assignment3Dec9;

import java.util.ArrayDeque;
//import java.util.Collections;
//import java.util.Iterator;
//import java.util.LinkedList;

public class sample  {

	public static void main(String[] args) {
	ArrayDeque<Integer> deque=new	ArrayDeque<Integer>();
	deque.push(1);
	deque.push(2);
	deque.push(3);
	deque.poll();
	System.out.println(deque);

	}

}
