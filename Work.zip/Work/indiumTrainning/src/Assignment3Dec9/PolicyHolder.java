package Assignment3Dec9;

public class PolicyHolder {
	
	String name ;
	int age ;
	String Aadhar;
	String PAN;
	long Mobile;
	public String getName() {
		return name;
	}
	public String setName(String name) {
		 return this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAadhar() {
		return Aadhar;
	}
	public void setAadhar(String aadhar) {
		Aadhar = aadhar;
	}
	public String getPAN() {
		return PAN;
	}
	public void setPAN(String pAN) {
		PAN = pAN;
	}
	public long getMobile() {
		return Mobile;
	}
	public void setMobile(long mobile) {
		Mobile = mobile;
	}
	

}
