package AssignmentsUptoJan3;

public class GuessTheNumber {

	public static void main(String[] args) {
		System.out.println("WElcome to Guess the NUMber Game");
		System.out.println("Enter the Number bt(50 to 150)");
		GuessingNumbers  gn = new GuessingNumbers();
		gn.Numbers();
		


}
}
