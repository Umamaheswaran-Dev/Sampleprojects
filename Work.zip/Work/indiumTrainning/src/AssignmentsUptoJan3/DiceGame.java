package AssignmentsUptoJan3;

public class DiceGame {

	public static void main(String[] args) {
		ThrowingDice td = new ThrowingDice();
		td.Winnings();

	}

}
