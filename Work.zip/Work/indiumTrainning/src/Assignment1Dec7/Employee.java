package Assignment1Dec7;

public class Employee {
	String firstName;
	String lastName;
	String empId;
	long monthlySalary;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public long getMonthlySalary() {
		return monthlySalary;
	}
	public void setMonthlySalary(long monthlySalary) {
		this.monthlySalary = monthlySalary;
	}
	

}
